let carrinho = [];
function adicionarCarrinho(item) {
  carrinho.push(item);
  atualizarCarrinho();
}
function atualizarCarrinho() {
  const lista = document.getElementById('carrinho');
  lista.innerHTML = '';
  carrinho.forEach(produto => {
    const li = document.createElement('li');
    li.textContent = produto;
    lista.appendChild(li);
  });
}